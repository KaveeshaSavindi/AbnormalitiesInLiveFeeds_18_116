# emgucv-face-detection

![Face detection sample](https://3.bp.blogspot.com/-XUug8yzvIs0/WH2HyR7DXSI/AAAAAAAACbo/mXhODHU6afsxH2PcQacF3RlfVMJ0iP5fgCLcB/s1600/lena-win.jpg)

C# face detection with Emgu CV code sample

[Complete Tutorial](https://www.junian.net/2014/07/camera-face-detection-in-c-using-emgu.html)
